public class gorillaTest {
    public static void main(String[] args) {
        Gorilla Kong = new Gorilla(100);
        Kong.throwSomething();
        Kong.throwSomething();
        Kong.eatBananas();
        Kong.throwSomething();
        Kong.climb();
        Kong.eatBananas();
    }
}

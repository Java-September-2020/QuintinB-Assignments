public class humanTest {
    public static void main(String[] args) {
        Human Shawn = new Human();
        Human Drake = new Human();
        Shawn.attack(Drake);
    }
}

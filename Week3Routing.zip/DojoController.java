package com.quintinbowman.week3Routing;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DojoController {

	@RequestMapping("/dojo/{place}")
	public String dojo(@PathVariable("place")String location) {
		if(location.equalsIgnoreCase("burbank")) {
			return "Burbank Dojo is located in Southern California.";
			
		}
		else if(location.equalsIgnoreCase("san-jose")) {
			return "SJ is the dojo headquarters.";
		
		}
		else {
		return "The dojo is awesome sauce.";
		
		}
		
	}
}

package com.quintinbowman.week3Routing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class CodingController {
	
	public static void main(String[] args) {
		SpringApplication.run(CodingController.class, args);
	}
	
	@RequestMapping("/coding")
		public String index() {
			return "Hello, Coding Dojo";
	}
	
	@RequestMapping("/coding/python")
	public String python() {
		return "Python/Django is awesome sauce!"; 
	}
	
	@RequestMapping("/coding/java")
	public String java() {
		return "Java/Spring is better, you'd get lost in the sauce";
	}
}

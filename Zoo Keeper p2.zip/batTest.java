public class batTest {
    public static void main(String[] args) {
        Bat Bruce = new Bat(100);
        Bruce.fly();
        Bruce.attackTown();
        Bruce.eatHuman();
        Bruce.attackTown();
        Bruce.eatHuman();
        Bruce.attackTown();
        Bruce.fly();

    }
}
